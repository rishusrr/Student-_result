# ResultManagementSystem_PHP
Result Management System in PHP 


Admin Pasword

admin
Test@123

For Configuration Watch Video
